# Task-05: Traffic Accident Pattern Analysis

## Objective
Analyze traffic accident data to identify patterns related to road conditions, weather, and time of day. Visualize accident hotspots and contributing factors.

## Dataset
This project uses a simulated traffic accident dataset (`accident_data.csv`).

## Files
- `traffic_accident_analysis.py`: Python script to process and visualize accident data.
- `accident_data.csv`: Sample dataset of accidents.
- `README.md`: Instructions and descriptions.

## Requirements
- Python 3.x
- pandas
- seaborn
- matplotlib

## Usage
1. Install dependencies:
```
pip install pandas matplotlib seaborn
```

2. Run the script:
```
python traffic_accident_analysis.py
```
