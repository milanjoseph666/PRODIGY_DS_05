import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt

# Load dataset
df = pd.read_csv('accident_data.csv')

# Convert time column
df['time'] = pd.to_datetime(df['time'], format='%H:%M').dt.hour

# Plot accidents by time of day
plt.figure(figsize=(10, 5))
sns.histplot(df['time'], bins=24, kde=False, color='skyblue')
plt.title('Accidents by Hour of Day')
plt.xlabel('Hour of Day')
plt.ylabel('Accident Count')
plt.tight_layout()
plt.savefig("accidents_by_hour.png")
plt.show()

# Plot accidents by weather condition
plt.figure(figsize=(8, 5))
sns.countplot(data=df, x='weather', order=df['weather'].value_counts().index, palette='Set3')
plt.title('Accidents by Weather Condition')
plt.xlabel('Weather')
plt.ylabel('Count')
plt.tight_layout()
plt.savefig("accidents_by_weather.png")
plt.show()

# Plot accidents by road condition
plt.figure(figsize=(8, 5))
sns.countplot(data=df, x='road_condition', order=df['road_condition'].value_counts().index, palette='coolwarm')
plt.title('Accidents by Road Condition')
plt.xlabel('Road Condition')
plt.ylabel('Count')
plt.tight_layout()
plt.savefig("accidents_by_road_condition.png")
plt.show()
